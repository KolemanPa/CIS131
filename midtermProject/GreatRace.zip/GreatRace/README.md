#THE GREAT RACE
## this project required creating a fair "race" in between two "charectors" and the result would be random like the speed and who wins
